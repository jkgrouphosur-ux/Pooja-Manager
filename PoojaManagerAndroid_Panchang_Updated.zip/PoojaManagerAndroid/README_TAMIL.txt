ஸ்ரீ முரளி ஸ்ரீனிவாசன் ஐயர் – Android App Project

இது Android Studio-வில் APK உருவாக்குவதற்கான source project. இது APK கோப்பு அல்ல.

APK உருவாக்க:
1. கணினியில் Android Studio நிறுவவும்.
2. இந்த ZIP-ஐ Extract செய்து PoojaManager கோப்புறையை Android Studio-வில் Open செய்யவும்.
3. Gradle Sync முடியும் வரை காத்திருக்கவும். Android SDK Platform 35 நிறுவப்பட வேண்டும்.
4. Build > Build Bundle(s) / APK(s) > Build APK(s) தேர்வு செய்யவும்.
5. APK: app/build/outputs/apk/debug/app-debug.apk

செயலி உள்ளடக்கம் assets/index.html-ல் உள்ளது. பூஜை விவரங்கள் WebView local storage-ல் அந்த சாதனத்தில் சேமிக்கப்படும். Firebase / multi-device login இல்லை.

முக்கியம்: இந்த சூழலில் Android SDK / Gradle build tools இல்லை. எனவே APK-ஐ இங்கே compile செய்து சோதிக்க முடியவில்லை. இந்த ZIP Android Studio project source மட்டுமே; APK என்று தவறாகக் கருத வேண்டாம்.
